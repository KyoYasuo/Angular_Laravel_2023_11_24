export class Track {
    index?: number;
    link: string;
    title: string;
}