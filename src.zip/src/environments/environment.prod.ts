export const environment = {
  production: true,
  BASE_API_URL: 'https://apiprod.khojgurbani.org/api/v1',
  OFFICIAL_SITE_URL: "https://www.khojgurbani.org",
  GOOGLE_CLIENT_ID:  "27095017027-3pm15omfb0n5tbffu124i45han7b2p40.apps.googleusercontent.com",/*27095017027-8jcsl272e0auvf0pv72i4q3ugdbslt9q.apps.googleusercontent.com*/
  FACEBOOK_APP_ID: "269167221120152",
  BACKEND_URL: 'https://apiprod.khojgurbani.org',
  FRONTEND_URL: 'https://www.khojgurbani.org',
  URL: 'https://apiprod.khojgurbani.org/api/v1/',
};
