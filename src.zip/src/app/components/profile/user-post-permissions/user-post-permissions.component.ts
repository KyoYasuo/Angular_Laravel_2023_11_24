import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-post-permissions',
  templateUrl: './user-post-permissions.component.html',
  styleUrls: ['./user-post-permissions.component.scss']
})
export class UserPostPermissionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
