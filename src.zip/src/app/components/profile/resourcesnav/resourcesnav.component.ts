import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resourcesnav',
  templateUrl: './resourcesnav.component.html',
  styleUrls: ['./resourcesnav.component.scss']
})
export class ResourcesnavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
