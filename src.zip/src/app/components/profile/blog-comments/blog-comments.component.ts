import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-comments',
  templateUrl: './blog-comments.component.html',
  styleUrls: ['./blog-comments.component.scss']
})
export class BlogCommentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
